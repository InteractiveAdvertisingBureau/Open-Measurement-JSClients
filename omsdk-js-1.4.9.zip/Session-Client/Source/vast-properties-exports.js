goog.module('omid.sessionClient.VastPropertiesExports');

const VastProperties = goog.require('omid.common.VastProperties');
const {packageExport} = goog.require('omid.common.exporter');

packageExport('OmidSessionClient.VastProperties', VastProperties);
