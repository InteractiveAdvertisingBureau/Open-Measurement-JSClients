goog.module('omid.common.version');

/**
 * The version of the OMID Verification Client JS API provided by this code.
 * @const {string}
 */
exports.ApiVersion = '1.0';

/**
 * The version of the OMID service code.
 * @const {string}
 */
exports.Version = '1.4.9-iab4257';
